package com.LibraryManagementSystem.dao;

import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

/**
 * DAO class for managing Rental entity operations in the library management system.
 */
public class RentalDAO {

    
     //Saves a new rental record in the database.
     
     
    public static void saveRental(Rental rental) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            try {
                session.save(rental);
                transaction.commit();
            } catch (Exception e) {
                transaction.rollback();
                System.err.println("Failed to save rental record: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    // Retrieves a rental record for a specific user and book.
     
    public static Rental getRentalByUserAndBook(Long userId, Long bookId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            List<Rental> rentals = session.createQuery(
                            "FROM Rental WHERE user.id = :userId AND book.id = :bookId", Rental.class)
                    .setParameter("userId", userId)
                    .setParameter("bookId", bookId)
                    .getResultList();

            if (rentals.isEmpty()) {
                System.out.printf("No rental record found for user ID %d and book ID %d.%n", userId, bookId);
                return null;
            }

            if (rentals.size() > 1) {
                System.out.println("Warning: Multiple rental records found for the same user and book. Returning the most recent one.");
            }

            // Return the most recent rental (assuming the list is ordered by date, adjust logic if not)
            return rentals.get(rentals.size() - 1);
        }
    }

    
     //Retrieves all rental records for a specific user.
     
    public static List<Rental> getRentalsByUser(Long userId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Rental WHERE user.id = :userId", Rental.class)
                    .setParameter("userId", userId)
                    .getResultList();
        }
    }

    
     //Updates an existing rental record in the database.
     
    public static void updateRental(Rental rental) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            try {
                session.update(rental);
                transaction.commit();
            } catch (Exception e) {
                transaction.rollback();
                System.err.println("Failed to update rental record: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
