package com.LibraryManagementSystem.dao;

import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class RentalDAO {

    public static void saveRental(Rental rental) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(rental);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public static Rental getRentalByUserAndBook(Long userId, Long bookId) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            // Fetch all rentals for the given user and book
            List<Rental> rentals = session.createQuery("FROM Rental WHERE user.id = :userId AND book.id = :bookId", Rental.class)
                                          .setParameter("userId", userId)
                                          .setParameter("bookId", bookId)
                                          .getResultList();

            if (rentals.size() == 1) {
                return rentals.get(0);  // Return the rental if only one is found
            } else if (rentals.size() > 1) {
                // Handle the case where there are multiple rentals (e.g., log a warning or pick the most recent one)
                System.out.println("Warning: Found multiple rentals for the same book and user. Returning the most recent one.");
                return rentals.get(rentals.size() - 1);  // Assuming you want to pick the most recent one, or adjust logic as needed
            } else {
                System.out.println("No rental record found for user ID " + userId + " and book ID " + bookId);
                return null;
            }
        } finally {
            session.close();
        }
    }


    public static List<Rental> getRentalsByUser(Long userId) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            return session.createQuery("FROM Rental WHERE user.id = :userId", Rental.class)
                    .setParameter("userId", userId)
                    .getResultList();
        } finally {
            session.close();
        }
    }

    public static void updateRental(Rental rental) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.update(rental);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        
        
    }
    
    
}
