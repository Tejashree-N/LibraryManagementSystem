package com.LibraryManagementSystem.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.util.HibernateUtil;
import java.util.List;

public class BookDAO {

    // Add a new book to the database
    public boolean addBook(Book book) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(book); // Save the book
            transaction.commit();
            System.out.println("Book added successfully with ID: " + book.getId());
            return true; // Successfully added
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); // Rollback in case of an error
            }
            e.printStackTrace();
            System.out.println("Error occurred while adding the book.");
            return false; // Failed to add the book
        }
    }

    // Retrieve all books from the database
    public static List<Book> getAllBooks() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Book", Book.class).list();
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null in case of an error
        }
    }

    // Update an existing book in the database
    public static boolean updateBook(Book book) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(book); // Update the book
            transaction.commit();
            System.out.println("Book updated successfully with ID: " + book.getId());
            return true; // Successfully updated
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); // Rollback in case of an error
            }
            e.printStackTrace();
            System.out.println("Error occurred while updating the book.");
            return false; // Failed to update the book
        }
    }

    // Delete a book by its ID
    public boolean deleteBook(Long id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Book book = session.get(Book.class, id);
            if (book != null) {
                session.delete(book); // Delete the book
                transaction.commit();
                System.out.println("Book deleted successfully with ID: " + id);
                return true; // Successfully deleted
            } else {
                transaction.rollback();
                System.out.println("Error: Book not found with ID: " + id);
                return false; // Book not found
            }
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); // Rollback in case of an error
            }
            e.printStackTrace();
            System.out.println("Error occurred while deleting the book with ID: " + id);
            return false; // Failed to delete the book
        }
    }

    // Retrieve a book by its ID
    public static Book getBookById(Long bookId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Book.class, bookId); // Fetch the book
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null in case of an error
        }
    }

    // Update the price of a book by its ID
    public boolean updateBookPrice(Long bookId, double price) {
        if (price <= 0) {
            System.out.println("Error: Price must be greater than 0.");
            return false; // Invalid price
        }

        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Book book = session.get(Book.class, bookId);
            if (book != null) {
                book.setPrice(price); // Update the price
                session.update(book);
                transaction.commit();
                System.out.println("Price updated successfully for book with ID: " + bookId);
                return true; // Successfully updated
            } else {
                transaction.rollback();
                System.out.println("Error: Book not found with ID: " + bookId);
                return false; // Book not found
            }
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); // Rollback in case of an error
            }
            e.printStackTrace();
            System.out.println("Error occurred while updating the price of the book with ID: " + bookId);
            return false; // Failed to update the price
        }
    }

}
