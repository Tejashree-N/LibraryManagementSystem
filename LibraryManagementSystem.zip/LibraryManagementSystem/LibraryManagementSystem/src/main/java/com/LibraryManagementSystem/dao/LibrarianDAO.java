package com.LibraryManagementSystem.dao;

import com.LibraryManagementSystem.entity.Librarian;
import com.LibraryManagementSystem.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.query.Query;

public class LibrarianDAO {

    // Method to retrieve librarian by email
    public static Librarian getLibrarianByEmail(String email) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Librarian WHERE email = :email";
            Query<Librarian> query = session.createQuery(hql, Librarian.class);
            query.setParameter("email", email);
            return query.uniqueResult();  // Return null if not found
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;  // Return null if no librarian found
    }

    // Method to save librarian to the database
    public static void saveLibrarian(Librarian librarian) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(librarian);
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
