package com.LibraryManagementSystem.service;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.dao.BuyDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Buy;
import com.LibraryManagementSystem.entity.User;

import java.time.LocalDate;
import java.util.List;

public class BuyService {

    public static void buyBook(User user, Long bookId, int quantity) {       
        Book book = BookDAO.getBookById(bookId);
        if (book != null && book.getQuantity() >= quantity) {
            // Decrease book quantity
            book.setQuantity(book.getQuantity() - quantity);
            BookDAO.updateBook(book);

            // Create Buy record
            Buy buy = new Buy();
            buy.setUser(user);
            buy.setBook(book);
            buy.setQuantity(quantity);
            buy.setTotalPrice(book.getPrice() * quantity);
            buy.setPurchaseDate(LocalDate.now());
            BuyDAO.saveBuy(buy);

            System.out.printf("Book '%s' bought successfully by '%s'. Total Price: Rs %.2f\n", 
                    book.getTitle(), user.getName(), buy.getTotalPrice());
        } else {
            System.out.println("Insufficient stock to complete the purchase.");
        }
    }

    // Fetch all purchased books by a user
    public static List<Buy> getPurchasesByUser(User user) {
        return BuyDAO.getPurchasesByUser(user); // Assuming BuyDAO has this method to retrieve user purchases
    }
}
