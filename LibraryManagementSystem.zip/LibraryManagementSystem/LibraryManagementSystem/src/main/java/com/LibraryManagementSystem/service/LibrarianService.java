package com.LibraryManagementSystem.service;

import com.LibraryManagementSystem.dao.LibrarianDAO;
import com.LibraryManagementSystem.entity.Librarian;

public class LibrarianService {

    // This method is used to find a librarian by email and password (for login)
    public Librarian login(String email, String password) {
        try {
            Librarian librarian = LibrarianDAO.getLibrarianByEmail(email);
            if (librarian != null && librarian.getPassword().equals(password)) {
                return librarian;  // Librarian found and credentials are correct
            }
        } catch (Exception e) {
            System.out.println("Librarian not found.");
        }
        return null;  // Invalid credentials
    }

    // This method is used to create a librarian only if not already present
    public static void createLibrarian() {
        String email = "tejashree@gmail.com";

        // Check if librarian with this email already exists
        Librarian existingLibrarian = LibrarianDAO.getLibrarianByEmail(email);

        if (existingLibrarian == null) {
            // Only create the librarian if they don't already exist
            Librarian librarian = new Librarian("Tejashree", email, "Tejashree@123");
            LibrarianDAO.saveLibrarian(librarian);  // Save to the database using LibrarianDAO
            System.out.println("librarian created successfully.");
        } else {
            System.out.println("Librarian already exists.");
        }
    }

}
