package com.LibraryManagementSystem;

import java.util.List;
import java.util.Scanner;
import java.util.InputMismatchException;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Buy;
import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.service.BookService;
import com.LibraryManagementSystem.service.BuyService;
import com.LibraryManagementSystem.service.RentalService;
import com.LibraryManagementSystem.service.UserService;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        // Initialize services
        UserService userService = new UserService();
        BookService bookService = new BookService();
        RentalService rentalService = new RentalService();
        Scanner scanner = new Scanner(System.in);

        // Sample Librarian registration (Librarian user creation)
        userService.registerUser("Librarian", "tejashreenyaynirgune@gmail.com", "Tejashree@123", "9977411381", "Chembur Mumbai", "Librarian");

        System.out.println("-----------Welcome to Library Management System!-----------");

        // Main menu loop
        while (true) {
        	System.out.println("\n1. Librarian Login\n2. User Registration\n3. User Login\n4. Exit");
            int choice = getIntInput(scanner, "Enter your choice: ");
            if (choice == -1) continue;  // Skip loop if invalid input

            switch (choice) {
                case 1:
                    // Librarian Login
                    System.out.print("Enter Librarian Email: ");
                    String adminEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String adminPassword = scanner.nextLine();

                    // Librarian login logic
                    User admin = userService.login(adminEmail, adminPassword);
                    if (admin != null && "Librarian".equals(admin.getRole())) {
                        System.out.println("-----------Librarian logged in successfully.-----------");

                        // Admin menu loop
                        while (true) {
                            int adminChoice = getIntInput(scanner, "\n1. Add Book\n2. Update Book\n3. Delete Book\n4. View Books \n5. Set Book Price\n6. View All Users\n7. View Rented Books by User\n8. View Purchased Books by User\n9. Logout\nEnter your choice: ");
                            if (adminChoice == -1) continue;  // Skip loop if invalid input

                            if (adminChoice == 9) break; // Logout

                            switch (adminChoice) {
                                case 1:
                                    // Add Book
                                    System.out.print("Enter Title: ");
                                    String title = scanner.nextLine();
                                    System.out.print("Enter Author: ");
                                    String author = scanner.nextLine();
                                    System.out.print("Enter ISBN: ");
                                    String isbn = scanner.nextLine();
                                    int quantity = getIntInput(scanner, "Enter Quantity: ");
                                    double price = getDoubleInput(scanner, "Enter Price: ");
                                    bookService.addBook(title, author, isbn, quantity, price);
                                    System.out.println("------Book added successfully.------");
                                    break;

                                case 2:
                                    // Update Book
                                    Long updateId = getLongInput(scanner, "Enter Book ID: ");
                                    System.out.print("Enter New Title: ");
                                    String newTitle = scanner.nextLine();
                                    System.out.print("Enter New Author: ");
                                    String newAuthor = scanner.nextLine();
                                    System.out.print("Enter New ISBN: ");
                                    String newIsbn = scanner.nextLine();
                                    int newQuantity = getIntInput(scanner, "Enter New Quantity: ");
                                    double newPrice = getDoubleInput(scanner, "Enter New Price: ");
                                    bookService.updateBook(updateId, newTitle, newAuthor, newIsbn, newQuantity, newPrice);
                                    System.out.println("-------Book updated successfully.-------");
                                    break;

                                case 3:
                                    // Delete Book
                                    Long deleteId = getLongInput(scanner, "Enter Book ID: ");
                                    bookService.deleteBook(deleteId);
                                    System.out.println("-------Book deleted successfully.-------");
                                    break;

                                case 4:
                                    // View Books
                                    List<Book> books = BookDAO.getAllBooks();
                                    System.out.println("Available Books:");
                                    for (Book b : books) {
                                        System.out.printf("ID: %d, Title: %s, Author: %s, ISBN: %s, Quantity: %d, Price: %.2f\n",
                                                b.getId(), b.getTitle(), b.getAuthor(), b.getIsbn(), b.getQuantity(), b.getPrice());
                                    }
                                    break;

                                case 5:
                                    // Set Book Price
                                    Long bookId = getLongInput(scanner, "Enter Book ID to set price: ");
                                    double NewPrice = getDoubleInput(scanner, "Enter Price for the Book: ");
                                    bookService.setBookPrice(bookId, NewPrice);
                                    System.out.println("-------Price updated successfully.-------");
                                    break;

                                case 6:
                                    // View All Users
                                    List<User> users = userService.getAllUsers();
                                    System.out.println("Registered Users:");
                                    for (User u : users) {
                                        System.out.printf("ID: %d, Name: %s, Email: %s, Phone: %s, Address: %s, Role: %s\n",
                                                u.getId(), u.getName(), u.getEmail(), u.getPhone(), u.getAddress(), u.getRole());
                                    }
                                    break;
                                    
                                case 7:  // View Rented Books by User
                                    System.out.print("Enter User Name to view rented books: ");
                                    String userNameToSearchForRental = scanner.nextLine();

                                    User userToViewRentals = userService.getUserByName(userNameToSearchForRental); // Fetch the user by username
                                    
                                    if (userToViewRentals != null) {
                                        RentalService.viewRentedBooksByUser(userToViewRentals);  // Fetch and display rented books with penalties
                                    } else {
                                        System.out.println("User not found.");
                                    }
                                    break;
                                    
                                case 8:  // View Purchased Books by User
                                    System.out.print("Enter User Name to view purchased books: ");
                                    String userNameToSearchForPurchase = scanner.nextLine();

                                    User userToViewPurchases = userService.getUserByName(userNameToSearchForPurchase); // Fetch the user by username
                                    
                                    if (userToViewPurchases != null) {
                                        List<Buy> userPurchases = BuyService.getPurchasesByUser(userToViewPurchases);  // Fetch the purchases

                                        if (userPurchases.isEmpty()) {
                                            System.out.println(userNameToSearchForPurchase + " has not purchased any books.");
                                        } else {
                                            System.out.println("-----Purchased Books by " + userNameToSearchForPurchase + "------");
                                            for (Buy purchase : userPurchases) {
                                                System.out.println("Book ID: " + purchase.getBook().getId() + " - Book Title: " + purchase.getBook().getTitle() + 
                                                    " - Quantity: " + purchase.getQuantity() + " - Price: Rs " + purchase.getTotalPrice() + " - Purchase Date: " + purchase.getPurchaseDate());
                                            }
                                        }
                                    } else {
                                        System.out.println("User not found.");
                                    }
                                    break;


                                default:
                                    System.out.println("Invalid choice.");
                            }
                        }
                    } else {
                        System.out.println("Invalid Librarian credentials.");
                    }
                    break;

                case 2:
                    // User Registration
                    System.out.print("Enter Name: ");
                    String userName = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String userEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String userPassword = scanner.nextLine();
                    System.out.print("Enter Phone: ");
                    String userPhone = scanner.nextLine();
                    System.out.print("Enter Address: ");  
                    String userAddress = scanner.nextLine();

                    // Password validation
                    if (!userService.isValidPassword(userPassword)) {
                        System.out.println("Invalid password! It must be at least 8 characters long, include one uppercase letter, one lowercase letter, one digit, and one special character.");
                        break;
                    }

                    // Register the user
                    boolean registered = userService.registerUser(userName, userEmail, userPassword, userPhone, userAddress, "user");
                    System.out.println(registered ? "User registered successfully." : "Email already exists.");
                    break;

                case 3:
                    // User Login
                    System.out.print("Enter Email: ");
                    String loginEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String loginPassword = scanner.nextLine();

                    // User login logic
                    User user = userService.login(loginEmail, loginPassword);
                    if (user != null && "user".equals(user.getRole())) {
                        System.out.println("-------User logged in successfully.------");

                        // User menu loop
                        while (true) {
                            int userChoice = getIntInput(scanner, "\n1. View Books\n2. Borrow Book\n3. Return Book\n4. Buy Book\n5. View rented Books\n6. Logout\nEnter your choice: ");
                            if (userChoice == -1) continue;  // Skip loop if invalid input

                            if (userChoice == 6) break; // Logout

                            switch (userChoice) {
                                case 1:
                                    // View Books
                                    List<Book> books = BookDAO.getAllBooks();
                                    System.out.println("Available Books:");
                                    for (Book b : books) {
                                        System.out.printf("ID: %d, Title: %s, Author: %s, ISBN: %s, Quantity: %d, Price: %.2f\n",
                                                b.getId(), b.getTitle(), b.getAuthor(), b.getIsbn(), b.getQuantity(), b.getPrice());
                                    }
                                    break;

                                case 2:
                                    // Borrow Book
                                    Long borrowBookId = getLongInput(scanner, "Enter Book ID to Borrow: ");
                                    if (RentalService.borrowBook(user, borrowBookId)) {
                                        System.out.println("------Book borrowed successfully.-------");
                                    } else {
                                        System.out.println("-------Book not available.------");
                                    }
                                    break;

                                case 3:
                                    // Return Book
                                    Long returnBookId = getLongInput(scanner, "Enter Book ID to Return: ");
                                    boolean isReturned = RentalService.returnBook(user, returnBookId);
                                    if (isReturned) {
                                        Rental rental = RentalService.getUserRentals(user).stream()
                                                .filter(r -> r.getBook().getId().equals(returnBookId))
                                                .findFirst().orElse(null);
                                        
                                        if (rental != null) {
                                            // Calculate penalty if returned late
                                            double penalty = RentalService.calculatePenalty(rental);
                                            if (penalty > 0) {
                                                System.out.printf("You have a penalty of Rs %.2f for returning the book late.\n", penalty);
                                            } else {
                                                System.out.println("---Book returned on time. No penalty.---");
                                            }
                                        }
                                    } else {
                                        System.out.println("---Failed to return the book.---");
                                    }
                                    break;

                                case 4: // Buy Book
                                    System.out.print("Enter Book ID to Buy: ");
                                    Long buyBookId = scanner.nextLong();
                                    scanner.nextLine(); // Consume newline

                                    // Prompt for quantity to buy
                                    System.out.print("Enter quantity to buy: ");
                                    int quantityToBuy = scanner.nextInt();
                                    scanner.nextLine(); // Consume newline

                                    // Call the buyBook method without assigning to a boolean variable
                                    BuyService.buyBook(user, buyBookId, quantityToBuy);

                                    // After calling buyBook, you can show a success or failure message
                                    System.out.println("------Book bought successfully.------");
                                    break;


                                case 5:
                                    // View rented books
                                    List<Rental> rentals = RentalService.getUserRentals(user);
                                    if (rentals.isEmpty()) {
                                        System.out.println("No book rented.");
                                    } else {
                                        System.out.println("-----Currently rented books------");
                                        for (Rental rental : rentals) {
                                            System.out.println("Book ID: " + rental.getBook().getId() + " - Rented Date: " + rental.getRentedDate());
                                        }
                                    }
                                    break;

                                default:
                                    System.out.println("Invalid choice.");
                            }
                        }
                    } else {
                        System.out.println("Invalid user credentials.");
                    }
                    break;

                case 4:
                    // Exit the system
                    System.out.println("-----Thank You For Using Libraray Management System-----");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // Helper method to get an integer input with validation
    private static int getIntInput(Scanner scanner, String prompt) {
        int value = -1;
        while (true) {
            System.out.print(prompt);
            try {
                value = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine();  // Clear the invalid input
            }
        }
        return value;
    }

    // Helper method to get a long input with validation
    private static long getLongInput(Scanner scanner, String prompt) {
        long value = -1;
        while (true) {
            System.out.print(prompt);
            try {
                value = scanner.nextLong();
                scanner.nextLine();  // Consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine();  // Clear the invalid input
            }
        }
        return value;
    }

    // Helper method to get a double input with validation
    private static double getDoubleInput(Scanner scanner, String prompt) {
        double value = -1;
        while (true) {
            System.out.print(prompt);
            try {
                value = scanner.nextDouble();
                scanner.nextLine();  // Consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine();  // Clear the invalid input
            }
        }
        return value;
    }
} 