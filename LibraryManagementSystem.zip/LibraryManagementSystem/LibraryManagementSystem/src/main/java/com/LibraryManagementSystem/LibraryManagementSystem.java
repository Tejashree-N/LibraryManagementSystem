package com.LibraryManagementSystem;

import java.util.List;
import java.util.Scanner;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.service.BookService;
import com.LibraryManagementSystem.service.RentalService;
import com.LibraryManagementSystem.service.UserService;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        UserService userService = new UserService();
        BookService bookService = new BookService();
        RentalService rentalService = new RentalService();
        Scanner scanner = new Scanner(System.in);

        // Sample Librarian registration
        userService.registerUser("Librarian", "tejashreenyaynirgune@gmail.com", "Tejashree@123", "9977411381","Chembur Mumbai", "Librarian");

        System.out.println("-----------Welcome to Library Management System!-----------");

        while (true) {
            System.out.println("\n1. Librarian Login\n2. User Registration\n3. User Login\n4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Librarian Email: ");
                    String adminEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String adminPassword = scanner.nextLine();

                    User admin = userService.login(adminEmail, adminPassword);
                    if (admin != null && "Librarian".equals(admin.getRole())) {
                        System.out.println("-----------Librarian logged in successfully.-----------");

                        while (true) {
                            System.out.println("\n1. Add Book\n2. Update Book\n3. Delete Book\n4. View Books \n5. Set Book Price\n6. View All Users\n7. Logout");
                            System.out.print("Enter your choice: ");
                            int adminChoice = scanner.nextInt();
                            scanner.nextLine();

                            if (adminChoice == 7)
                            	break;

                            switch (adminChoice) {
                                case 1:
                                    System.out.print("Enter Title: ");
                                    String title = scanner.nextLine();
                                    System.out.print("Enter Author: ");
                                    String author = scanner.nextLine();
                                    System.out.print("Enter ISBN: ");
                                    String isbn = scanner.nextLine();
                                    System.out.print("Enter Quantity: ");
                                    int quantity = scanner.nextInt();
                                    System.out.print("set price: ");
                                    double price = scanner.nextDouble();
                                    bookService.addBook(title, author, isbn, quantity, price);
                                    System.out.println("------Book added successfully.------");
                                    break;

                                case 2:
                                    System.out.print("Enter Book ID: ");
                                    Long updateId = scanner.nextLong();
                                    scanner.nextLine();
                                    System.out.print("Enter New Title: ");
                                    String newTitle = scanner.nextLine();
                                    System.out.print("Enter New Author: ");
                                    String newAuthor = scanner.nextLine();
                                    System.out.print("Enter New ISBN: ");
                                    String newIsbn = scanner.nextLine();
                                    System.out.print("Enter New Quantity: ");
                                    int newQuantity = scanner.nextInt();
                                    System.out.print("Enter New Price: ");
                                    double newPrice = scanner.nextDouble();
                                    scanner.nextLine();;
                                    bookService.updateBook(updateId, newTitle, newAuthor, newIsbn, newQuantity, newPrice);
                                    System.out.println("-------Book updated successfully.-------");
                                    break;

                                case 3:
                                    System.out.print("Enter Book ID: ");
                                    Long deleteId = scanner.nextLong();
                                    bookService.deleteBook(deleteId);
                                    System.out.println("-------Book deleted successfully.-------");
                                    break;

                                case 4: // View Books
                                    List<Book> books = BookDAO.getAllBooks();
                                    System.out.println("Available Books:");
                                    for (Book b : books) {
                                        System.out.printf("ID: %d, Title: %s, Author: %s, ISBN: %s, Quantity: %d, Price: %.2f\n",
                                                b.getId(), b.getTitle(), b.getAuthor(), b.getIsbn(), b.getQuantity(), b.getPrice());
                                    }
                                    break;

                                case 5: // Set Book Price
                                    System.out.print("Enter Book ID to set price: ");
                                    Long bookId = scanner.nextLong();
                                    System.out.print("Enter Price for the Book: ");
                                    double newprice = scanner.nextDouble();
                                    bookService.setBookPrice(bookId, newprice);
                                    System.out.println("-------Price updated successfully.-------");
                                    break;
                                    
                                case 6:  // View All Users
                                    List<User> users = userService.getAllUsers();
                                    System.out.println("Registered Users:");
                                    for (User u : users) {
                                        System.out.printf("ID: %d, Name: %s, Email: %s, Phone: %s, Address: %s, Role: %s\n",
                                                u.getId(), u.getName(), u.getEmail(), u.getPhone(), u.getAddress(), u.getRole());
                                    }
                                    break;

                                default:
                                    System.out.println("Invalid choice.");
                            }
                        }
                    } else {
                        System.out.println("Invalid Librarian credentials.");
                    }
                    break;

                case 2:
                    System.out.print("Enter Name: ");
                    String userName = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String userEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String userPassword = scanner.nextLine();
                    System.out.print("Enter Phone: ");
                    String userPhone = scanner.nextLine();
                    System.out.print("Enter Address: ");  
                    String userAddress = scanner.nextLine();

                    if (!userService.isValidPassword(userPassword)) {
                        System.out.println("Invalid password! It must be at least 8 characters long, include one uppercase letter, one lowercase letter, one digit, and one special character.");
                        break;
                    }

                    boolean registered = userService.registerUser(userName, userEmail, userPassword, userPhone,userAddress, "user");
                    System.out.println(registered ? "User registered successfully." : "Email already exists.");
                    break;

                case 3:
                    System.out.print("Enter Email: ");
                    String loginEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String loginPassword = scanner.nextLine();

                    User user = userService.login(loginEmail, loginPassword);
                    if (user != null && "user".equals(user.getRole())) {
                        System.out.println("-------User logged in successfully.------");
                        while (true) {
                            System.out.println("\n1. View Books\n2. Borrow Book\n3. Return Book\n4. Buy Book\n5. View rented Books\n6. Logout");
                            System.out.print("Enter your choice: ");
                            int userChoice = scanner.nextInt();
                            scanner.nextLine(); // Consume newline

                            if (userChoice == 6) break;

                            switch (userChoice) {
                                case 1: // View Books
                                    List<Book> books = BookDAO.getAllBooks();
                                    System.out.println("Available Books:");
                                    for (Book b : books) {
                                        System.out.printf("ID: %d, Title: %s, Author: %s, ISBN: %s, Quantity: %d, Price: %.2f\n",
                                                b.getId(), b.getTitle(), b.getAuthor(), b.getIsbn(), b.getQuantity(), b.getPrice());
                                    }
                                    break;

                                case 2: // Borrow Book
                                    System.out.print("Enter Book ID to Borrow: ");
                                    Long borrowBookId = scanner.nextLong();
                                    scanner.nextLine(); // Consume newline

                                    if (RentalService.borrowBook(user, borrowBookId)) {
                                        System.out.println("------Book borrowed successfully.-------");
                                    } else {
                                        System.out.println("-------Book not available.------");
                                    }
                                    break;

                                case 3: // Return Book
                                    System.out.print("Enter Book ID to Return: ");
                                    Long returnBookId = scanner.nextLong();
                                    scanner.nextLine(); // Consume newline

                                    boolean isReturned = RentalService.returnBook(user, returnBookId);
                                    if (isReturned) {
                                        Rental rental = RentalService.getUserRentals(user).stream()
                                                .filter(r -> r.getBook().getId().equals(returnBookId))
                                                .findFirst().orElse(null);
                                        
                                        if (rental != null) {
                                            // Calculate penalty if returned late
                                            double penalty = RentalService.calculatePenalty(rental);
                                            if (penalty > 0) {
                                                System.out.printf("You have a penalty of Rs %.2f for returning the book late.\n", penalty);
                                            } else {
                                                System.out.println("---Book returned on time. No penalty.---");
                                            }
                                        }
                                    } else {
                                        System.out.println("---Failed to return the book.---");
                                    }
                                    break;

                                case 4: // Buy Book
                                    System.out.print("Enter Book ID to Buy: ");
                                    Long buyBookId = scanner.nextLong();
                                    scanner.nextLine(); // Consume newline

                                    boolean isBought = RentalService.buyBook(user, buyBookId);
                                    if (isBought) {
                                        System.out.println("------Book bought successfully.------");
                                    } else {
                                        System.out.println("Could not buy the book.");
                                    }
                                    break;

                                case 5: // View rented books
                                    List<Rental> rentals = RentalService.getUserRentals(user);
                                    System.out.println("-----Currently rented books------");
                                    for (Rental rental : rentals) {
                                        System.out.println("Book ID: " + rental.getBook().getId() + " - Rented Date: " + rental.getRentedDate());
                                    }
                                    break;

                                default:
                                    System.out.println("Invalid choice.");
                            }
                        }
                    } else {
                        System.out.println("Invalid user credentials.");
                    }
                    break;

                case 4:
                    System.out.println("------Exiting...------");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
