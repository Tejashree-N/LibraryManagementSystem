package com.LibraryManagementSystem.service;

import java.util.List;
import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.entity.Book;

public class BookService {
    private BookDAO bookDAO = new BookDAO();
    
    // Validate if book exists
    public boolean isBookExists(Long bookId) {
        return BookDAO.getBookById(bookId) != null;
    }

    // Validate book title (not null or empty)
    public boolean isValidTitle(String title) {
        return title != null && !title.trim().isEmpty();
    }

    // Validate author name (only letters and spaces)
    public boolean isValidAuthor(String author) {
        String authorPattern = "^[a-zA-Z\\s]+$"; // Only letters and spaces
        return author != null && author.matches(authorPattern);
    }

    // Validate ISBN (13 digits for simplicity)
    public boolean isValidIsbn(String isbn) {
        String isbnPattern = "^[0-9]{13}$"; // 13 digits ISBN
        return isbn != null && isbn.matches(isbnPattern);
    }

    // Validate quantity (must be a positive integer)
    public boolean isValidQuantity(int quantity) {
        return quantity > 0;
    }

    // Validate price (must be a positive number)
    public boolean isValidPrice(double price) {
        return price > 0;
    }

    // Add a new book with validation
    public boolean addBook(String title, String author, String isbn, int quantity, double price) {
        // Validate inputs
        if (!isValidTitle(title)) {
            System.out.println("Invalid title. Title cannot be empty.");
            return false;
        }
        if (!isValidAuthor(author)) {
            System.out.println("Invalid author name. Only letters and spaces are allowed.");
            return false;
        }
        if (!isValidIsbn(isbn)) {
            System.out.println("Invalid ISBN. ISBN must be exactly 13 digits.");
            return false;
        }
        if (!isValidQuantity(quantity)) {
            System.out.println("Invalid quantity. Quantity must be a positive integer.");
            return false;
        }
        if (!isValidPrice(price)) {
            System.out.println("Invalid price. Price must be a positive number.");
            return false;
        }

        // Create the book object
        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setQuantity(quantity);
        book.setPrice(price);

        // Add the book to the database
        try {
            boolean added = bookDAO.addBook(book); // Assuming addBook returns true/false
            if (added) {
//                System.out.println("Book added successfully!");
                return true;
            } else {
                System.out.println("Book with this ISBN already exists.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while adding the book: " + e.getMessage());
            return false;
        }
    }

    // Get all books
    public List<Book> getAllBooks() {
        return BookDAO.getAllBooks();
    }

    // Update an existing book with validation
    public boolean updateBook(Long id, String title, String author, String isbn, int quantity, double price) {
        // Validate inputs
        if (!isValidTitle(title)) {
            System.out.println("Invalid title. Title cannot be empty.");
            return false;
        }
        if (!isValidAuthor(author)) {
            System.out.println("Invalid author name. Only letters and spaces are allowed.");
            return false;
        }
        if (!isValidIsbn(isbn)) {
            System.out.println("Invalid ISBN. ISBN must be exactly 13 digits.");
            return false;
        }
        if (!isValidQuantity(quantity)) {
            System.out.println("Invalid quantity. Quantity must be a positive integer.");
            return false;
        }
        if (!isValidPrice(price)) {
            System.out.println("Invalid price. Price must be a positive number.");
            return false;
        }

        // If all validations pass, proceed to update the book
        Book book = new Book();
        book.setId(id);
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setQuantity(quantity);
        book.setPrice(price); // Set the new price

        try {
            boolean updated = BookDAO.updateBook(book);  // Check if update was successful
            if (updated) {
                System.out.println("Book updated successfully!");
                return true; // Successfully updated
            } else {
                System.out.println("Failed to update the book.");
                return false; // Failed to update
            }
        } catch (Exception e) {
            System.out.println("An error occurred while updating the book: " + e.getMessage());
            return false;
        }
    }

    // Delete a book by its ID with validation, return boolean
    public boolean deleteBook(Long id) {
        if (isBookExists(id)) {
            try {
                boolean deleted = bookDAO.deleteBook(id); // Attempt to delete the book
                if (deleted) {
                    System.out.println("Book deleted successfully!");
                    return true; // Successfully deleted
                } else {
                    System.out.println("Failed to delete the book.");
                    return false; // Failed to delete
                }
            } catch (Exception e) {
                System.out.println("Error occurred while deleting the book: " + e.getMessage());
                return false; // Error during deletion
            }
        } else {
            System.out.println("Book not found with ID: " + id);
            return false; // Book not found
        }
    }

    // Method to set the price of a book with validation, return boolean
    public boolean setBookPrice(Long bookId, double price) {
        if (!isValidPrice(price)) {
            System.out.println("Invalid price. Price must be a positive number.");
            return false; // Invalid price
        }

        if (isBookExists(bookId)) {
            try {
                Book book = BookDAO.getBookById(bookId);
                if (book != null) {
                    book.setPrice(price); // Update the price of the book
                    boolean updated = BookDAO.updateBook(book); // Save the updated book in the database
                    if (updated) {
                        System.out.println("Book price updated successfully!");
                        return true; // Successfully updated
                    } else {
                        System.out.println("Failed to update the book price.");
                        return false; // Failed to update the price
                    }
                } else {
                    System.out.println("Book not found with ID: " + bookId);
                    return false; // Book not found
                }
            } catch (Exception e) {
                System.out.println("Error occurred while updating the price: " + e.getMessage());
                return false; // Error during price update
            }
        } else {
            System.out.println("Book not found with ID: " + bookId);
            return false; // Book not found
        }
    }

	
}
