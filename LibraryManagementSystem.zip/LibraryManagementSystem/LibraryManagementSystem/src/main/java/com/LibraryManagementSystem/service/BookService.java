package com.LibraryManagementSystem.service;

import java.util.List;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.entity.Book;

public class BookService {
    private BookDAO bookDAO = new BookDAO(); // Use proper camel case for variable name
    

    // Add a new book
    public void addBook(String title, String author, String isbn, int quantity, double price) {
        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setQuantity(quantity);
        book.setPrice(price); // Set price of the book
        bookDAO.addBook(book);
    }

    // Get all books
    public List<Book> getAllBooks() {
        return BookDAO.getAllBooks();
    }

    // Update an existing book
    public void updateBook(Long id, String title, String author, String isbn, int quantity, double price) {
        Book book = new Book();
        book.setId(id);
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setQuantity(quantity);
        book.setPrice(price); // Set the new price
        BookDAO.updateBook(book);
    }

    // Delete a book by its ID
    public void deleteBook(Long id) {
        bookDAO.deleteBook(id);
        
    }
        
 // Method to set the price of a book
    public void setBookPrice(Long bookId, double price) {
        Book book = BookDAO.getBookById(bookId);
        if (book != null) {
            book.setPrice(price); // Update the price of the book
            BookDAO.updateBook(book); // Save the updated book in the database
        } else {
            System.out.println("Book not found.");
        }
    }
    
}
