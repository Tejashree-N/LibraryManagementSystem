package com.LibraryManagementSystem.service;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.dao.RentalDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.entity.User;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class RentalService {

    // Borrow Book
    public static boolean borrowBook(User user, Long bookId) {
        Book book = BookDAO.getBookById(bookId);
        if (book != null && book.getQuantity() > 0) {
            book.setQuantity(book.getQuantity() - 1);
            BookDAO.updateBook(book);

            // Create rental record
            Rental rental = new Rental();
            rental.setUser(user);
            rental.setBook(book);
            rental.setRentedDate(LocalDate.now());
            RentalDAO.saveRental(rental);

            return true;
        }
        return false;
    }

    // Return Book
    public static boolean returnBook(User user, Long bookId) {
        Rental rental = RentalDAO.getRentalByUserAndBook(user.getId(), bookId);
        if (rental != null) {
            // Mark the book as returned by updating rental record
            rental.setReturnedDate(LocalDate.now());
            RentalDAO.updateRental(rental);

            // Increase book quantity
            Book book = rental.getBook();
            book.setQuantity(book.getQuantity() + 1);
            BookDAO.updateBook(book);

            return true;
        }
        return false;
    }

    // Get User Rentals
    public static List<Rental> getUserRentals(User user) {
        return RentalDAO.getRentalsByUser(user.getId());
    }

    // Calculate Penalty for late returns
    public static double calculatePenalty(Rental rental) {
        if (rental.getReturnedDate() != null && rental.getRentedDate() != null) {
            long daysRented = ChronoUnit.DAYS.between(rental.getRentedDate(), rental.getReturnedDate());
            if (daysRented > 14) {
                // Calculate penalty: Rs 15 per extra day
                long overdueDays = daysRented - 14;
                return overdueDays * 15; // 15 Rs per overdue day
            }
        }
        return 0.0;
    }

    // Buy Book - allows a user to buy a book
    public static boolean buyBook(User user, Long bookId) {
        Book book = BookDAO.getBookById(bookId);
        if (book != null && book.getQuantity() > 0) {
            // Decrease book quantity
            book.setQuantity(book.getQuantity() - 1);
            BookDAO.updateBook(book);

            // Optionally, create a purchase record, but since the user buys it, we just update the stock
            // (purchase record can be added if necessary)

            System.out.printf("Book '%s' bought successfully by user '%s'.\n", book.getTitle(), user.getName());
            return true;
        }
        return false;
    }

    // Set Book Price - allows a librarian to set or update the price of a book
    public static boolean setBookPrice(Long bookId, double price) {
        Book book = BookDAO.getBookById(bookId);
        if (book != null) {
            book.setPrice(price);  // Update price
            BookDAO.updateBook(book);  // Save changes to the database
            System.out.printf("Price of the book '%s' updated to Rs %.2f.\n", book.getTitle(), price);
            return true;
        }
        return false;
    }
}
