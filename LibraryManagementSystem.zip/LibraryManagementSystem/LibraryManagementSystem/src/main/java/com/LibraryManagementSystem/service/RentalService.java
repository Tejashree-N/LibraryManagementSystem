package com.LibraryManagementSystem.service;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.dao.RentalDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.entity.User;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class RentalService {

    // Borrow Book
    public static boolean borrowBook(User user, Long bookId) {
        Book book = BookDAO.getBookById(bookId);
        if (book != null && book.getQuantity() > 0) {
            book.setQuantity(book.getQuantity() - 1);
            BookDAO.updateBook(book);

            // Create rental record
            Rental rental = new Rental();
            rental.setUser(user);
            rental.setBook(book);
            rental.setRentedDate(LocalDate.now());
            RentalDAO.saveRental(rental);

            return true;
        }
        return false;
    }

    // Return Book
    public static boolean returnBook(User user, Long bookId) {
        Rental rental = RentalDAO.getRentalByUserAndBook(user.getId(), bookId);
        if (rental != null) {
            // Mark the book as returned by updating rental record
            rental.setReturnedDate(LocalDate.now());
            RentalDAO.updateRental(rental);

            // Increase book quantity
            Book book = rental.getBook();
            book.setQuantity(book.getQuantity() + 1);
            BookDAO.updateBook(book);

            return true;
        }
        return false;
    }

    // Get User Rentals
    public static List<Rental> getUserRentals(User user) {
        return RentalDAO.getRentalsByUser(user.getId());
    }

    // Calculate Penalty for late returns
    public static double calculatePenalty(Rental rental) {
        if (rental.getReturnedDate() != null && rental.getRentedDate() != null) {
            long daysRented = ChronoUnit.DAYS.between(rental.getRentedDate(), rental.getReturnedDate());
            if (daysRented > 14) {
                // Calculate penalty: Rs 15 per extra day
                long overdueDays = daysRented - 14;
                return overdueDays * 15; // 15 Rs per overdue day
            }
        }
        return 0.0;
    }

    // View rented books by user (for librarian)
    public static void viewRentedBooksByUser(User user) {
        List<Rental> rentals = RentalDAO.getRentalsByUser(user.getId());

        if (rentals.isEmpty()) {
            System.out.println(user.getName() + " has not rented any books.");
        } else {
            System.out.println("-----Rented Books by " + user.getName() + "-----");
            for (Rental rental : rentals) {
                Book rentedBook = rental.getBook();
                LocalDate rentedDate = rental.getRentedDate();
                LocalDate returnedDate = rental.getReturnedDate();
                double penalty = (returnedDate != null) ? calculatePenalty(rental) : 0.0;

                System.out.println("Book ID: " + rentedBook.getId() + " - Title: " + rentedBook.getTitle() +
                        " - Rented Date: " + rentedDate + " - Returned Date: " + (returnedDate != null ? returnedDate : "Not returned yet") +
                        " - Penalty: Rs " + penalty);
            }
        }
    }
}
