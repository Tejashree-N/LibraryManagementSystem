package com.LibraryManagementSystem.dao;

import com.LibraryManagementSystem.entity.Buy;
import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.util.HibernateUtil;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.hibernate.Transaction;

public class BuyDAO {

    public static void saveBuy(Buy buy) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(buy);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Get all purchases made by a specific user
    public static List<Buy> getPurchasesByUser(User user) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Create a query to get all purchases by the user
            Query<Buy> query = session.createQuery("FROM Buy WHERE user = :user", Buy.class);
            query.setParameter("user", user);
            return query.list();  // Return the list of purchases made by the user
        }
    }
}
