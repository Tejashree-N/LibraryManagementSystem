package com.LibraryManagementSystem.dao;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.util.HibernateUtil;

public class UserDAO {
    public void saveUser(User user) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
        }
    }

    public User getUserByEmail(String email) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<User> query = session.createQuery("FROM User WHERE email = :email", User.class);
            query.setParameter("email", email);
            return query.uniqueResult();
        }
    }
    
 // Get all users
    public List<User> getAllUsers() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Create a query to get all users
            Query<User> query = session.createQuery("FROM User", User.class);
            return query.list();  // Return the list of users
        }
    }
    
 // Get user by name
    public User getUserByName(String name) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<User> query = session.createQuery("FROM User WHERE name = :name", User.class);
            query.setParameter("name", name);
            return query.uniqueResult();  // Return the user if found, otherwise null
        }
    }
}
