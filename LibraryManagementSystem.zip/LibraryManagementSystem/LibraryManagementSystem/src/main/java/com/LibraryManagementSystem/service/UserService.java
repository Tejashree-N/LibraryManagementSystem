package com.LibraryManagementSystem.service;

import java.util.List;

import com.LibraryManagementSystem.dao.UserDAO;
import com.LibraryManagementSystem.entity.User;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    // Validate password (at least 8 characters, including one uppercase, one lowercase, one digit, and one special character)
    public boolean isValidPassword(String password) {
        String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        return password != null && password.matches(passwordPattern);
    }

    // Validate name (only letters and spaces)
    public boolean isValidName(String name) {
        String namePattern = "^[a-zA-Z\\s]+$";
        return name != null && name.matches(namePattern);
    }

    // Validate email (standard email pattern)
    public boolean isValidEmail(String email) {
        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email != null && email.matches(emailPattern);
    }

    // Validate phone (10-digit number)
    public boolean isValidPhone(String phone) {
        String phonePattern = "^[0-9]{10}$";
        return phone != null && phone.matches(phonePattern);
    }

    // Validate address (allow alphanumeric characters, spaces, commas, periods, hyphens)
    public boolean isValidAddress(String address) {
        String addressPattern = "^[a-zA-Z0-9\\s,.-]+$";  // Alphanumeric, spaces, and common punctuation (comma, period, hyphen)
        return address != null && address.length() <= 100 && address.matches(addressPattern);
    }

    // Validate city (only letters and spaces)
    public boolean isValidCity(String city) {
        String cityPattern = "^[a-zA-Z\\s]+$"; // Only letters and spaces
        return city != null && city.length() <= 10 && city.matches(cityPattern);
    }

    // Validate pincode (6 digits)
    public boolean isValidPincode(String pincode) {
        String pincodePattern = "^[0-9]{6}$"; // Exactly 6 digits
        return pincode != null && pincode.matches(pincodePattern);
    }

    // Register user
    public boolean registerUser(String name, String email, String password, String phone, String address, String city, String pincode) {
        // Check if email already exists
        if (userDAO.getUserByEmail(email) != null) {
            System.out.println("Email already exists.");
            return false;
        }

        // Validate inputs
        if (!isValidName(name)) {
            System.out.println("Invalid name. Name must contain only letters and spaces.");
            return false;
        }

        if (!isValidEmail(email)) {
            System.out.println("Invalid email format.");
            return false;
        }

        if (!isValidPhone(phone)) {
            System.out.println("Invalid phone number. Phone must be a 10-digit number.");
            return false;
        }

        // Validate address
        if (!isValidAddress(address)) {
            System.out.println("Invalid address. Address must be alphanumeric with a maximum of 100 characters.");
            return false;
        }

        // Validate city
        if (!isValidCity(city)) {
            System.out.println("Invalid city. City must contain only letters and spaces, with a maximum of 10 characters.");
            return false;
        }

        // Validate pincode
        if (!isValidPincode(pincode)) {
            System.out.println("Invalid pincode. Pincode must be exactly 6 digits.");
            return false;
        }

        // Validate password
        if (!isValidPassword(password)) {
            System.out.println("Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one digit, and one special character.");
            return false;
        }

        // Create and save user
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);
        user.setAddress(address);
        user.setCity(city);
        user.setPincode(pincode);
        userDAO.saveUser(user);  // Save the user using the DAO
        return true;
    }

    // Login user
    public User login(String email, String password) {
        User user = userDAO.getUserByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;  // Return null if user is not found or password is incorrect
    }

    // Get all users (for librarian to view user data)
    public List<User> getAllUsers() {
        return userDAO.getAllUsers();  // Get all users using the DAO
    }

    // Get user by name (for librarian to view rented books by username)
    public User getUserByName(String name) {
        return userDAO.getUserByName(name);  // Retrieve user by name
    }
}
