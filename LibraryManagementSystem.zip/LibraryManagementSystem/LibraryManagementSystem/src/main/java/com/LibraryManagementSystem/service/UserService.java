package com.LibraryManagementSystem.service;

import java.util.List;

import com.LibraryManagementSystem.dao.UserDAO;
import com.LibraryManagementSystem.entity.User;

public class UserService {
    private UserDAO userDAO = new UserDAO();
    
    // Validate password
    public boolean isValidPassword(String password) {
        // At least 8 characters, including one uppercase, one lowercase, one digit, and one special character
        String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        return password != null && password.matches(passwordPattern);
    }

    // Register user
    public boolean registerUser(String name, String email, String password, String phone, String address, String role) {
        // Check if email already exists
        if (userDAO.getUserByEmail(email) != null) {
            System.out.println("Email already exists.");
            return false;
        }

        // Validate password
        if (!isValidPassword(password)) {
            System.out.println("Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one digit, and one special character.");
            return false;
        }

        // Create and save user
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);
        user.setAddress(address);
        user.setRole(role);
        userDAO.saveUser(user);
        return true;
    }

    // Login user
    public User login(String email, String password) {
        User user = userDAO.getUserByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    // Get all users (for librarian to view user data)
    public List<User> getAllUsers() {
        return UserDAO.getAllUsers();  
    }

    // Get user by name (for librarian to view rented books by username)
    public User getUserByName(String name) {
        // Search for the user in the database or list (e.g., using UserDAO)
        return userDAO.getUserByName(name);
    }
}
