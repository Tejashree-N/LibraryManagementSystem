package com.LibraryManagementSystem.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.User;

import org.hibernate.HibernateException;

public class HibernateUtil {

    private static SessionFactory factory;

    static {
        try {
            System.out.println("Initializing Hibernate SessionFactory...");

            // Create the SessionFactory from hibernate.cfg.xml
            factory = new Configuration()
                    .configure("hibernate.cfg.xml")  // Ensure this points to the correct location of hibernate.cfg.xml
                    .addAnnotatedClass(User.class)
                    .addAnnotatedClass(Book.class)
                    .buildSessionFactory();
            
            if (factory != null) {
                System.out.println("SessionFactory initialized successfully.");
            } else {
                System.out.println("SessionFactory is null after initialization.");
            }

        } catch (HibernateException e) {
            e.printStackTrace();
            System.out.println("Hibernate SessionFactory initialization failed: " + e.getMessage());
        }
    }

    public static SessionFactory getSessionFactory() {
        return factory;
    }

    public static void shutdown() {
        if (factory != null) {
            factory.close();
        }
    }
}
