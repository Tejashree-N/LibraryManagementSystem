package com.LibraryManagementSystem;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.service.BookService;
import com.LibraryManagementSystem.service.RentalService;
import com.LibraryManagementSystem.service.UserService;
import com.LibraryManagementSystem.util.HibernateUtil;


public class LibraryManagementSystem 
{
	public static void main(String[] args) {
        UserService userService = new UserService();
        BookService bookService = new BookService();
        Scanner scanner = new Scanner(System.in);

        // Sample admin registration
        userService.registerUser("Admin", "tejashreenyaynirgune@gmail.com", "admin123", "7977411381", "admin");

        System.out.println("Welcome to Library Management System!");

        while (true) {
            System.out.println("\n1. Admin Login\n2. User Registration\n3. User Login\n4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Admin Email: ");
                    String adminEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String adminPassword = scanner.nextLine();

                    User admin = userService.login(adminEmail, adminPassword);
                    if (admin != null && "admin".equals(admin.getRole())) {
                        System.out.println("Admin logged in successfully.");

                        while (true) {
                            System.out.println("\n1. Add Book\n2. Update Book\n3. Delete Book\n4. Logout");
                            System.out.print("Enter your choice: ");
                            int adminChoice = scanner.nextInt();
                            scanner.nextLine();

                            if (adminChoice == 4) break;

                            switch (adminChoice) {
                                case 1:
                                    System.out.print("Enter Title: ");
                                    String title = scanner.nextLine();
                                    System.out.print("Enter Author: ");
                                    String author = scanner.nextLine();
                                    System.out.print("Enter ISBN: ");
                                    String isbn = scanner.nextLine();
                                    System.out.print("Enter Quantity: ");
                                    int quantity = scanner.nextInt();
                                    bookService.addBook(title, author, isbn, quantity);
                                    System.out.println("Book added successfully.");
                                    break;

                                case 2:
                                    System.out.print("Enter Book ID: ");
                                    Long updateId = scanner.nextLong();
                                    scanner.nextLine();
                                    System.out.print("Enter New Title: ");
                                    String newTitle = scanner.nextLine();
                                    System.out.print("Enter New Author: ");
                                    String newAuthor = scanner.nextLine();
                                    System.out.print("Enter New ISBN: ");
                                    String newIsbn = scanner.nextLine();
                                    System.out.print("Enter New Quantity: ");
                                    int newQuantity = scanner.nextInt();
                                    bookService.updateBook(updateId, newTitle, newAuthor, newIsbn, newQuantity);
                                    System.out.println("Book updated successfully.");
                                    break;

                                case 3:
                                    System.out.print("Enter Book ID: ");
                                    Long deleteId = scanner.nextLong();
                                    bookService.deleteBook(deleteId);
                                    System.out.println("Book deleted successfully.");
                                    break;

                                default:
                                    System.out.println("Invalid choice.");
                            }
                        }
                    } else {
                        System.out.println("Invalid admin credentials.");
                    }
                    break;

                case 2:
                    System.out.print("Enter Name: ");
                    String userName = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String userEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String userPassword = scanner.nextLine();
                    System.out.print("Enter Phone: ");
                    String userPhone = scanner.nextLine();

                    boolean registered = userService.registerUser(userName, userEmail, userPassword, userPhone, "user");
                    System.out.println(registered ? "User registered successfully." : "Email already exists.");
                    break;

                case 3:
                    System.out.print("Enter Email: ");
                    String loginEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String loginPassword = scanner.nextLine();

                    User user = userService.login(loginEmail, loginPassword);
                    if (user != null && "user".equals(user.getRole())) {
                        System.out.println("User logged in successfully.");
                        while (true) {
                            System.out.println("\n1. View Books\n2. Borrow Book\n3. Return Book\n4. View rented Books\n5. Logout");
                            System.out.print("Enter your choice: ");
                            int userChoice = scanner.nextInt();
                            scanner.nextLine(); // Consume newline

                            if (userChoice == 5) break;

                            switch (userChoice) {
                                case 1: // View Books
                                    List<Book> books = BookDAO.getAllBooks();
                                    System.out.println("Available Books:");
                                    for (Book b : books) {
                                        System.out.printf("ID: %d, Title: %s, Author: %s, ISBN: %s, Quantity: %d\n",
                                                b.getId(), b.getTitle(), b.getAuthor(), b.getIsbn(), b.getQuantity());
                                    }
                                    break;

                                case 2: // Borrow Book
                                    System.out.print("Enter Book ID to Borrow: ");
                                    Long borrowBookId = scanner.nextLong();
                                    scanner.nextLine(); // Consume newline

                                    if (RentalService.borrowBook(user, borrowBookId)) {
                                        System.out.println("Book borrowed successfully.");
                                    } else {
                                        System.out.println("Book not available.");
                                    }
                                    break;

                                case 3: // Return Book
                                    System.out.print("Enter Book ID to Return: ");
                                    Long returnBookId = scanner.nextLong();
                                    scanner.nextLine(); // Consume newline

                                    if (RentalService.returnBook(user, returnBookId)) {
                                        System.out.println("Book returned successfully.");
                                    } else {
                                        System.out.println("Failed to return the book.");
                                    }
                                    break;

                                case 4: // View rented books
                                    List<Rental> rentals = RentalService.getUserRentals(user);
                                    System.out.println("Currently rented books:");
                                    for (Rental rental : rentals) {
                                        System.out.println("Book ID: " + rental.getBook().getId() + " - Rented Date: " + rental.getRentedDate());
                                    }
                                   
                                    break;

                                default:
                                    System.out.println("Invalid choice.");
                            }
                        }
                    } else {
                        System.out.println("Invalid user credentials.");
                    }
                    break;
                    
                    
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
	}
