package com.LibraryManagementSystem;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.service.BookService;
import com.LibraryManagementSystem.service.UserService;
import com.LibraryManagementSystem.util.HibernateUtil;

/**
 * Hello world!
 *
 */
public class LibraryManagementSystem 
{
	 private static UserService userService = new UserService();
	    private static BookService bookService = new BookService();
	    private static Scanner scanner = new Scanner(System.in);

	    public static void main(String[] args) {
	        while (true) {
	            System.out.println("Welcome to Library Management System");
	            System.out.println("1. Register");
	            System.out.println("2. Login");
	            System.out.println("3. Exit");
	            int choice = scanner.nextInt();
	            scanner.nextLine();  // consume the newline

	            if (choice == 1) {
	                // Registration
	                System.out.print("Enter username: ");
	                String username = scanner.nextLine();
	                System.out.print("Enter password: ");
	                String password = scanner.nextLine();
	                boolean success = userService.registerUser(username, password);
	                if (success) {
	                    System.out.println("Registration Successful");
	                } else {
	                    System.out.println("Registration Failed");
	                }
	            } else if (choice == 2) {
	                // Login
	                System.out.print("Enter username: ");
	                String username = scanner.nextLine();
	                System.out.print("Enter password: ");
	                String password = scanner.nextLine();
	                User user = userService.loginUser(username, password);
	                if (user != null) {
	                    System.out.println("Login Successful");
	                    userMenu(user);  // Show user menu after successful login
	                } else {
	                    System.out.println("Invalid username or password");
	                }
	            } else if (choice == 3) {
	                System.out.println("Exiting the system.");
	                break;  // Exit the program
	            }
	        }
	    }

	    // Show the user menu after successful login
	    private static void userMenu(User user) {
	        while (true) {
	            System.out.println("\nLibrary Management Menu:");
	            System.out.println("1. Add Book");
	            System.out.println("2. View Books");
	            System.out.println("3. Update Book");
	            System.out.println("4. Delete Book");
	            System.out.println("5. Logout");
	            System.out.println("Enter your choice:");
	            int choice = scanner.nextInt();
	            scanner.nextLine();  // consume the newline

	            switch (choice) {
	                case 1:
	                    addBook();
	                    break;
	                case 2:
	                    viewBooks();
	                    break;
	                case 3:
	                    updateBook();
	                    break;
	                case 4:
	                    deleteBook();
	                    break;
	                case 5:
	                    System.out.println("Logging out...");
	                    return;  // Exit user menu and go back to the main menu
	                default:
	                    System.out.println("Invalid choice, please try again.");
	            }
	        }
	    }

	    private static void addBook() {
	        System.out.print("Enter book title: ");
	        String title = scanner.nextLine();
	        System.out.print("Enter author: ");
	        String author = scanner.nextLine();
	        System.out.print("Enter publisher: ");
	        String publisher = scanner.nextLine();
	        System.out.print("Enter ISBN: ");
	        String isbn = scanner.nextLine();
	        bookService.addBook(title, author, publisher, isbn);
	        System.out.println("Book Added Successfully");
	    }

	    private static void viewBooks() {
	        System.out.println("Books List:");
	        List<Book> books = bookService.viewBooks();
	        for (Book book : books) {
	            System.out.println(book.getId() + ". " + book.getTitle());
	        }
	    }

	    private static void updateBook() {
	        System.out.print("Enter book ID to update: ");
	        int id = scanner.nextInt();
	        scanner.nextLine();  // consume the newline
	        System.out.print("Enter new title: ");
	        String title = scanner.nextLine();
	        System.out.print("Enter new author: ");
	        String author = scanner.nextLine();
	        System.out.print("Enter new publisher: ");
	        String publisher = scanner.nextLine();
	        System.out.print("Enter new ISBN: ");
	        String isbn = scanner.nextLine();
	        bookService.updateBook(id, title, author, publisher, isbn);
	        System.out.println("Book Updated Successfully");
	    }

	    private static void deleteBook() {
	        System.out.print("Enter book ID to delete: ");
	        int bookId = scanner.nextInt();
	        scanner.nextLine();  // consume the newline
	        bookService.deleteBook(bookId);
	        System.out.println("Book Deleted Successfully");
	    }
	}
