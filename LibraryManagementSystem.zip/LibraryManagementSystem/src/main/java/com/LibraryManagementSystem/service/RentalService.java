package com.LibraryManagementSystem.service;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.dao.RentalDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.entity.User;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class RentalService {

    // Borrow Book
    public static boolean borrowBook(User user, Long bookId) {
        Book book = BookDAO.getBookById(bookId);
        if (book != null && book.getQuantity() > 0) {
            book.setQuantity(book.getQuantity() - 1);
            BookDAO.updateBook(book);

            // Create rental record
            Rental rental = new Rental();
            rental.setUser(user);
            rental.setBook(book);
            rental.setRentedDate(java.time.LocalDate.now());
            RentalDAO.saveRental(rental);

            return true;
        }
        return false;
    }

    // Return Book
    public static boolean returnBook(User user, Long bookId) {
        Rental rental = RentalDAO.getRentalByUserAndBook(user.getId(), bookId);
        if (rental != null) {
            // Mark the book as returned by updating rental record
            rental.setReturnedDate(java.time.LocalDate.now());
            RentalDAO.updateRental(rental);

            // Increase book quantity
            Book book = rental.getBook();
            book.setQuantity(book.getQuantity() + 1);
            BookDAO.updateBook(book);

            return true;
        }
        return false;
    }

    // Get User Rentals
    public static List<Rental> getUserRentals(User user) {
        return RentalDAO.getRentalsByUser(user.getId());
    }
}
