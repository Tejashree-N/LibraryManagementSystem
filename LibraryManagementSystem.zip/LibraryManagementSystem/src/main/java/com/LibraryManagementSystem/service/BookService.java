package com.LibraryManagementSystem.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.util.HibernateUtil;

import java.util.List;

public class BookService {

    private SessionFactory factory = HibernateUtil.getSessionFactory();

    public void addBook(String title, String author, String publisher, String isbn) {
        Session session = factory.getCurrentSession();
        try {
            session.beginTransaction();

            // Create new book object
            Book book = new Book(title, author, publisher, isbn);

            // Save the book
            session.save(book);

            // Commit the transaction
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();  // Always close the session
        }
    }

    public List<Book> viewBooks() {
        Session session = factory.getCurrentSession();
        try {
            session.beginTransaction();

            // Query to get all books
            Query<Book> query = session.createQuery("FROM Book", Book.class);
            List<Book> books = query.getResultList();

            session.getTransaction().commit();
            return books;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            session.close();  // Always close the session
        }
    }

    public void updateBook(int id, String title, String author, String publisher, String isbn) {
        Session session = factory.getCurrentSession();
        try {
            session.beginTransaction();

            // Retrieve the book to update
            Book book = session.get(Book.class, id);

            if (book != null) {
                book.setTitle(title);
                book.setAuthor(author);
                book.setPublisher(publisher);
                book.setIsbn(isbn);

                // Update the book
                session.update(book);
            }

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();  // Always close the session
        }
    }

    public void deleteBook(int bookId) {
        Session session = factory.getCurrentSession();
        try {
            session.beginTransaction();

            // Retrieve the book to delete
            Book book = session.get(Book.class, bookId);

            if (book != null) {
                session.delete(book);
            }

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();  // Always close the session
        }
    }
}
