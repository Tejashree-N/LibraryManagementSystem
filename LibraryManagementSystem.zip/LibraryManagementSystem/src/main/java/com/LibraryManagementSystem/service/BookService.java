package com.LibraryManagementSystem.service;
import java.util.List;

import com.LibraryManagementSystem.dao.BookDAO;
import com.LibraryManagementSystem.dao.RentalDAO;
import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.entity.Rental;
import com.LibraryManagementSystem.entity.User;

public class BookService {
    private BookDAO bookDAO = new BookDAO();

    public void addBook(String title, String author, String isbn, int quantity) {
        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setQuantity(quantity);
        bookDAO.addBook(book);
    }

    public List<Book> getAllBooks() {
        return bookDAO.getAllBooks();
    }

    public void updateBook(Long id, String title, String author, String isbn, int quantity) {
        Book book = new Book();
        book.setId(id);
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setQuantity(quantity);
        bookDAO.updateBook(book);
    }

    public void deleteBook(Long id) {
        bookDAO.deleteBook(id);
    }
    
}

