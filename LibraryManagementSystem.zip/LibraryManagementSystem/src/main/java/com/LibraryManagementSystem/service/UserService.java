package com.LibraryManagementSystem.service;

import com.LibraryManagementSystem.dao.UserDAO;
import com.LibraryManagementSystem.entity.User;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    public boolean registerUser(String name, String email, String password, String phone, String role) {
        if (userDAO.getUserByEmail(email) != null) {
            return false; // Email already exists
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);
        user.setRole(role);
        userDAO.saveUser(user);
        return true;
    }

    public User login(String email, String password) {
        User user = userDAO.getUserByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
    
    
}
