package com.LibraryManagementSystem.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.util.HibernateUtil;

public class UserService {

    private SessionFactory factory = HibernateUtil.getSessionFactory();

    public boolean registerUser(String username, String password) {
        Session session = factory.getCurrentSession();
        try {
            // Start a new session and transaction
            session.beginTransaction();

            // Create a new user object
            User user = new User(username, password);

            // Save the user
            session.save(user);

            // Commit the transaction
            session.getTransaction().commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            session.close();  // Always close the session
        }
    }

    public User loginUser(String username, String password) {
        Session session = factory.getCurrentSession();
        try {
            session.beginTransaction();

            // Query to check the credentials
            Query<User> query = session.createQuery("FROM User WHERE username = :username AND password = :password", User.class);
            query.setParameter("username", username);
            query.setParameter("password", password);

            User user = query.uniqueResult();

            session.getTransaction().commit();
            return user;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            session.close();  // Always close the session
        }
    }

}

