package com.LibraryManagementSystem.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.util.HibernateUtil;

import java.util.List;

public class BookDao {

    private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

    public void addBook(Book book) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(book);
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            transaction.rollback();
        } finally {
            session.close();
        }
    }

    public List<Book> viewBooks() {
        Session session = sessionFactory.openSession();
        List<Book> books = null;
        try {
            books = session.createQuery("FROM Book").list();
        } finally {
            session.close();
        }
        return books;
    }

    public void updateBook(Book book) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.update(book);
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            transaction.rollback();
        } finally {
            session.close();
        }
    }

    public void deleteBook(int bookId) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            Book book = session.get(Book.class, bookId);
            if (book != null) {
                session.delete(book);
            }
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            transaction.rollback();
        } finally {
            session.close();
        }
    }
}
