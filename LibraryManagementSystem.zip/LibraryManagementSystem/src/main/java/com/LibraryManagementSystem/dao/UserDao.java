package com.LibraryManagementSystem.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.LibraryManagementSystem.entity.User;
import com.LibraryManagementSystem.util.HibernateUtil;

public class UserDao {

    private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

    public boolean registerUser(User user) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(user);
            transaction.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            transaction.rollback();
            return false;
        } finally {
            session.close();
        }
    }

    public User loginUser(String username, String password) {
        Session session = sessionFactory.openSession();
        User user = null;
        try {
            user = (User) session.createQuery("FROM User WHERE username=:username AND password=:password")
                .setParameter("username", username)
                .setParameter("password", password)
                .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return user;
    }
}
