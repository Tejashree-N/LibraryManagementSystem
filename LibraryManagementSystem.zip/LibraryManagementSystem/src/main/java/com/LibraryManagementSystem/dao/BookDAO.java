package com.LibraryManagementSystem.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.LibraryManagementSystem.entity.Book;
import com.LibraryManagementSystem.util.HibernateUtil;

import java.util.List;

public class BookDAO {
    public void addBook(Book book) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(book);
            transaction.commit();
        }
    }

    public static List<Book> getAllBooks() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Book", Book.class).list();
        }
    }

    public static void updateBook(Book book) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.update(book);
            transaction.commit();
        }
    }

    public void deleteBook(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            Book book = session.get(Book.class, id);
            if (book != null) session.delete(book);
            transaction.commit();
            
            
        }
    }
    
    public static Book getBookById(Long bookId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Book.class, bookId);
        }
    }
}
